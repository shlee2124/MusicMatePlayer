//
//  MusicMatePlayer.h
//  MusicMatePlayer
//
//  Created by 1100442 on 2017. 8. 22..
//  Copyright © 2017년 sktechx. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MusicMatePlayer.
FOUNDATION_EXPORT double MusicMatePlayerVersionNumber;

//! Project version string for MusicMatePlayer.
FOUNDATION_EXPORT const unsigned char MusicMatePlayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MusicMatePlayer/PublicHeader.h>


